package simondarcyonline.flutter_cars

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
