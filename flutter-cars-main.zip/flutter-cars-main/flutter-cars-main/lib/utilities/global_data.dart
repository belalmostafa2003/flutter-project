import 'package:flutter_cars/utilities/search_data.dart';

SearchData gSearchData; //Search user search criteria
var dbClient; //Use dbCLient across the app
