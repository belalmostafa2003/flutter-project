// Example settings.dart file (rename me).
// App requires 2 keys. A CarTrawler client ID and a google maps API key.
// You can get and API key by following these steps https://developers.google.com/places/web-service/get-api-key

const GOOGLE_MAPS_API_KEY = "ADD YOUR GOOGLE MAPS API KEY HERE";
const CARTRAWLER_CLIENT_ID = 'ADD YOUR CARTRAWLER CLIENT ID HERE';
